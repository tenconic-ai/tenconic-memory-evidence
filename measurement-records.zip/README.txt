Primary recorded customer-support experiment: 240 answer calls, 16 questions x 3 repeats x 5 configurations.
Separate display receipts document two actual support demonstrations.
Refer to the English repository documents for metric definitions and cross-check instructions.
Original Korean data are preserved unchanged. No implementation or runtime source is included.
